# Investigación del producto 1731250336559629401

Producto: **sudadera para hombre con cuello tipo Perkins y cremallera**, corte entallado y manga larga. Tienda identificada por la API de producto como **Breitying** y por la vitrina como **breitying_menswearmx**. Mercado de venta: México. Categoría oficial: Ropa interior y de hombre → Camisas y abrigos para hombre → Sudaderas con gorro y suéteres.

Este informe interpreta únicamente las fuentes incluidas en el paquete. La consulta oficial se realizó el **17 de noviembre de 2026**, según los tiempos epoch registrados en `api_afiliados/consultas.json`. La ficha pública es una **captura archivada anterior a la exportación**. Sus valores se mantienen separados de la respuesta oficial actual.

## Información comercial recibida el 17 de noviembre

| Dato | Valor recibido | Fuente dentro del ZIP |
|---|---|---|
| Precio de lista | 332.47–334.25 MXN | `api_afiliados/producto_respuesta_original.json`, `data.products[0].original_price` |
| Precio con descuento del vendedor | 226.08–227.29 MXN | `api_afiliados/vitrina_respuesta_filtrada.json`, `data.products[0].price.seller_discount_price` |
| Precio con descuento de plataforma | 226.08–227.29 MXN | Mismo archivo, `price.platform_discount_price` |
| Comisión de afiliado | 8 %; importe declarado 18.09–18.18 MXN | Respuesta original de producto, `commission` |
| Comisión de Shop Ads | 3 % | Respuesta original de producto, `shop_ads_commission.rate = 300` |
| Inventario general | Disponible; vitrina `IN_STOCK` | Respuestas oficiales de producto y vitrina |
| Ventas globales declaradas | 1,152 unidades | Respuesta original de producto, `units_sold` |
| Estado de vitrina | Agregado, aprobado y visible | Respuesta de vitrina, `status` |
| Galería de vitrina | 9 referencias a imágenes | Respuesta de vitrina, `main_images` |

La operación de producto devolvió `sales_price` con sus cadenas vacías. Por eso el precio de venta de esta tabla procede de la **vitrina**. No se ha deducido un precio sustituyendo el campo vacío. La comisión monetaria es la cantidad declarada por la API, no una ganancia garantizada para cualquier compra.

La ficha de Corte consultada durante la exportación conservaba **1,151 ventas globales**, una menos que la consulta oficial directa. Esto demuestra que la aplicación puede estar leyendo una sincronización anterior. No deben sumarse esos contadores. La captura pública archivada declaraba **86,939** en `product_info.sold_count`; su diferencia de fuente, momento o alcance no está resuelta y no permite afirmar que el producto haya vendido esa cantidad en México ni calcular crecimiento.

## Descripción y variantes de la ficha pública archivada

La captura pública aporta **15 especificaciones** y **8 bloques de descripción**, conservados en `fuente_publica/producto_captura_original.json`. El vendedor describe una prenda entallada, de cuello alto corto con cremallera, manga larga, estilo deportivo, tejido con elasticidad media y material afelpado. Declara **95 % poliéster y 5 % elastano**, lavado a máquina y no limpieza en seco. Son afirmaciones publicadas por el vendedor; no representan una comprobación física del material o del rendimiento térmico.

La misma captura enumera cinco colores —**Signal black, Royal blue, Burgundy, White y Lilac**— y cinco tallas —**S, M, L, XL y XXL**—, con **23 SKU efectivamente recibidos**. No se han creado 25 combinaciones por multiplicar colores y tallas. Los ID, atributos, inventario y precios de cada SKU se conservan en el JSON y se facilitan en `tablas/variantes.csv`.

El precio público de esa captura era **213.53–214.86 MXN**, diferente al descuento oficial consultado para esta exportación. Los inventarios y precios de los SKU pertenecen a la captura archivada; requieren una nueva consulta para comprobar disponibilidad actual.

La captura incluye una **tabla de tallas en imagen**. La versión normalizada de Corte no contiene filas ni columnas transcritas (`columnas` y `filas` vacías, `unidad: null`), de modo que no se han inventado medidas ni unidades. Debe consultarse la imagen del paquete.

## Reseñas y fotos de compradores

La fuente pública declara una valoración agregada de **4.6** y un total de **60 reseñas**. Solo se recibieron **3 reseñas**, todas de cinco estrellas, acompañadas por **5 fotos**. Los tres indicadores `compra_verificada` disponibles son verdaderos. Texto, fecha, variante y asociación de cada foto se conservan en el JSON de evidencia y en la tabla de reseñas.

Los comentarios recibidos mencionan tejido grueso o afelpado, buena calidad, buen precio y ajuste a la talla. Esta es una síntesis de las tres opiniones disponibles; no describe las otras 57 ni permite concluir que todas las opiniones sean positivas. El promedio 4.6 procede del agregado de la fuente, no del promedio de estas tres opiniones, que sería 5.

En Corte, tallas y reseñas constan como consultadas en **`1794881743`**, equivalente a **2026-11-17 02:15:43 UTC** o **16 de noviembre de 2026, 20:15:43 en Ciudad de México**. Ese dato registra la lectura de evidencia guardada; no convierte la captura pública original en información actual al momento de exportar.

## Muestra y actividad del creador

La respuesta oficial de elegibilidad devuelve **`can_apply: false`** y **`status: "UNKNOWN"`**. No contiene un catálogo de SKU solicitables. Esto no demuestra que el producto carezca de variantes: la captura pública sí las enumera, desde otra fuente y momento.

La solicitud de muestra exportada corresponde a **negro intenso / XL**, de tipo `FREE_SAMPLE`, con estado oficial **`UNFULFILL_CANCELLED`**. Corte la clasifica como **vencida sin video**, a partir de su información de cumplimiento, y la marca como recibida. La clasificación de la aplicación y el estado oficial son campos distintos; deben preservarse ambos para que otra app pueda decidir su presentación.

La ficha exportada no registra pedidos válidos propios ni videos asociados al producto. `videos`, `serie` y `notas` están vacíos y no se aporta un archivo de video. Eso describe lo disponible en la ficha de Corte; no demuestra que no existan videos de terceros en TikTok.

## Qué contiene cada fuente y límites de la investigación

Las cuatro operaciones oficiales capturadas fueron: producto de colaboración abierta, elegibilidad de muestra, detalle de solicitud y lectura de vitrina. Todas devolvieron HTTP 200 y `code: 0`. Sus sobres conservan `message` y `request_id`; los parámetros funcionales y los tiempos están en `api_afiliados/consultas.json`.

Estas respuestas oficiales aportan información comercial, muestra y galería. La descripción extensa, las imágenes por color, los 23 SKU, la tabla de tallas y las reseñas de este paquete proceden de la **ficha pública archivada**, no de esas cuatro operaciones. La respuesta de Corte es otra representación: normaliza dinero a centavos, tasas a puntos base, clasifica actividad y sirve imágenes mediante su proxy.

La lectura no obtuvo todo el historial de reseñas, una verificación física de la prenda, ventas propias adicionales, videos descargables ni datos comerciales actuales por cada SKU. Tampoco constituye una comparación de mercado o una recomendación de compra. Los recursos multimedia descargados y cualquier incidencia están documentados en `media/indice.json`; el número de URLs puede incluir miniaturas, versiones o servidores alternativos de una misma imagen.

Enlaces públicos asociados al producto:

- [Ficha canónica de TikTok Shop México](https://shop.tiktok.com/mx/pdp/sudadera-ajustada-hombre-termica-estilo-casual-cuello-simulado/1731250336559629401).
- [Enlace de detalle devuelto por la API](https://shop.tiktok.com/view/product/1731250336559629401?region=MX&local=en).

Los enlaces identifican las fuentes; los hallazgos de este informe se sustentan en los archivos capturados incluidos en el ZIP.
