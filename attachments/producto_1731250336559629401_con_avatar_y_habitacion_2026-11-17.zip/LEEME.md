# Paquete de un producto de TikTok Shop

Producto: **sudadera para hombre con cuello tipo Perkins y cremallera, de Breitying**. ID: `1731250336559629401`. Exportación preparada el **17 de noviembre de 2026** para probar la importación en otra aplicación.

Este paquete reúne las respuestas oficiales obtenidas para ese producto, la ficha conservada por Corte y una captura pública archivada que aporta descripción, variantes, tallas y reseñas. Las fechas y las fuentes se conservan porque los precios, existencias y contadores pueden diferir.

## Qué abrir primero

- **`producto.json`**: entrada consolidada para importar el producto y sus referencias a archivos locales. Es una representación preparada para este ZIP; no es una respuesta original de TikTok.
- **`api_afiliados/producto_respuesta_original.json`**: respuesta oficial de producto, con su sobre y todos los campos recibidos en esa consulta.
- **`media/indice.json`**: relación de recursos, procedencia y archivos descargados. Consúltalo para distinguir fotos del catálogo, imágenes de variantes, tabla y fotos de reseñas, y para conocer cualquier descarga fallida.
- **`investigacion/INFORME.md`**: lectura humana de los datos y sus límites.

Descomprime el ZIP conservando sus carpetas. Resuelve las rutas locales a partir de la raíz del paquete; así la aplicación no depende de la sesión de Corte ni de que siga vigente una URL del CDN.

## Cómo manda la información la API

La API devuelve **JSON** por HTTPS. Las respuestas oficiales capturadas tienen esta estructura:

```json
{
  "code": 0,
  "data": { "products": [] },
  "message": "Success",
  "request_id": "identificador de la petición"
}
```

`data` cambia según la operación: producto, vitrina, elegibilidad de muestra o solicitud. Las imágenes llegan principalmente como **URLs**, no como archivos adjuntos dentro del JSON. Para este paquete se han incluido los recursos descargados y su índice. La respuesta JSON de una operación tampoco reúne por sí sola todas las fuentes de una investigación.

Las consultas, métodos, parámetros funcionales y fechas están en **`api_afiliados/consultas.json`**. No contiene secretos, firmas de peticiones ni cabeceras de autorización.

## Avatar y habitacion del usuario

Las seis imagenes adjuntadas se incluyen como originales, sin recortes ni cambios:

- `avatar/`: cinco fotos, identificadas como retrato frontal, cuerpo completo de frente, espaldas y los dos perfiles.
- `habitacion/`: una imagen de la habitacion.
- `referencias.json`: indice general con rutas, vistas, dimensiones y SHA-256. Cada subcarpeta tambien tiene su `indice.json`.
- `producto.json`: las mismas rutas se encuentran en `referencias.avatar` y `referencias.habitacion`, listas para consumir desde otra app.

Estas imagenes fueron proporcionadas por el usuario; su procedencia queda separada de los datos de TikTok. Las 52 imagenes del producto se conservan y el paquete contiene ahora 58 archivos de imagen en total.

## Archivos y procedencia

| Carpeta o archivo | Contenido |
|---|---|
| `api_afiliados/producto_respuesta_original.json` | Respuesta oficial de colaboración abierta: título, categoría, precio de lista, comisión, inventario y ventas globales declaradas. |
| `api_afiliados/vitrina_respuesta_filtrada.json` | Respuesta oficial de vitrina conservando todos los campos del producto elegido. Se excluyeron los demás productos de la página; el total y cursor siguen siendo los originales de la página, no cantidades de este ZIP. |
| `api_afiliados/vitrina_seleccion.json` | Registro de esa selección de un solo producto. |
| `api_afiliados/muestra_elegibilidad_respuesta_original.json` | Resultado de elegibilidad para solicitar una muestra. |
| `api_afiliados/muestra_solicitud_respuesta_original.json` | Solicitud asociada al producto, incluida la variante solicitada y su estado oficial. |
| `corte/` | Respuestas de la aplicación: campos normalizados, clasificación de muestra, imágenes mediante proxy y evidencia pública ya guardada. |
| `fuente_publica/producto_captura_original.json` | Bloque del producto extraído de una captura pública archivada de TikTok Shop México. Conserva información que no llegó en las operaciones oficiales capturadas. |
| `tablas/variantes.csv` | Variantes de la captura pública, para inspección o importación tabular. |
| `tablas/resenas.csv` | Reseñas disponibles, para inspección o importación tabular. |
| `media/` | Archivos descargados e índice de sus relaciones con los datos. |
| `verificacion_lectura.json` | Producto seleccionado y verificación de lectura sin renovación OAuth ni cambio de credenciales. |

## Reglas para importar sin perder información

1. Trata los **IDs como texto**. Los identificadores largos de producto, SKU, reseña y solicitud exceden la precisión segura de un número JavaScript. En una hoja de cálculo, importa esas columnas como texto.
2. Los importes oficiales como `"226.08"` son cadenas decimales en la moneda indicada. En Corte, `22608` en un campo terminado en `_centavos` equivale a **226.08 MXN**.
3. Las tasas en puntos base se dividen entre 100 para expresarlas en porcentaje: `800` = **8 %**; `300` = **3 %**. No las interpretes como 800 % o 300 %.
4. Conserva `null`, cadenas vacías, listas vacías y campos ausentes. Un precio vacío no equivale a cero; `UNKNOWN` no describe un motivo específico de rechazo.
5. Las fechas de Corte con sufijo `_at` son segundos desde el epoch UTC. En la captura pública, campos como `review_time` están en milisegundos. Consulta la fuente antes de convertirlos.
6. Las rutas `/img/...` de las respuestas de Corte requieren su servidor y autorización. Para pruebas independientes utiliza los archivos locales y el índice de medios.

## Alcance

Se incluyen **los datos disponibles de este producto en las fuentes capturadas**. Hay **3 reseñas de un total declarado de 60**, una tabla de tallas en imagen y **23 SKU de una captura pública archivada**. Esos SKU no constituyen una consulta actual de inventario. No hay videos del producto ni ventas propias registradas en la ficha exportada. Las ventas globales de TikTok no son ventas del creador.

Los archivos oficiales denominados `respuesta_original` conservan sus campos JSON; el formato de espacios puede cambiar respecto del transporte. La respuesta filtrada de vitrina y `producto.json` son transformaciones identificadas. La ficha pública es una fuente diferente a la API oficial de afiliados. El paquete no incluye credenciales ni una conexión reutilizable a la API.
